package com.mindtree.kalinga.service;

import java.util.List;

import com.mindtree.kalinga.entity.Mindtree;
import com.mindtree.kalinga.exception.ServiceException;

public interface Mindtreeservice {
	public void insertmind(Mindtree m) throws ServiceException;

	public List<Mindtree> getAllminds();
}
