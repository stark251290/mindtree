package com.mindtree.kalinga.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.mindtree.kalinga.exception.ConnectionfailedException;

public class JdbcConnection {
	private static JdbcConnection jdbcConnection;
	private static Connection dbConnection;

	private JdbcConnection() {
	}

	public static JdbcConnection getInstance() {
		if (jdbcConnection == null)
			jdbcConnection = new JdbcConnection();
		return jdbcConnection;

	}

	public static void createConnection() throws ConnectionfailedException {
		try {
			dbConnection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mindtree", "root", "Welcome123");
		} catch (SQLException e) {
			throw new ConnectionfailedException("Error creating the connection to database", e);
		}
		System.out.println("Connection to db Established!");
	}

	public static Connection getConnection() {
		return dbConnection;
	}

	public static void closeConnection() throws ConnectionfailedException {
		try {
			dbConnection.close();
		} catch (SQLException e) {
			throw new ConnectionfailedException("connection  not closed properly", e);

		}
	}

}
