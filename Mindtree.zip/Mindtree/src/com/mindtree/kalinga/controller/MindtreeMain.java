package com.mindtree.kalinga.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.mindtree.kalinga.entity.Mindtree;
import com.mindtree.kalinga.exception.ConnectionfailedException;
import com.mindtree.kalinga.exception.ServiceException;
import com.mindtree.kalinga.service.Mindtreeservice;
import com.mindtree.kalinga.serviceimp.Mindtreeserviceimp;
import com.mindtree.kalinga.utility.JdbcConnection;

public class MindtreeMain {
	static Scanner in = new Scanner(System.in);
	static Mindtreeservice ms = new Mindtreeserviceimp();

	public static void main(String[] args)  {
		try {
			JdbcConnection.createConnection();
		} catch (ConnectionfailedException e) {
			System.out.println("Not able to connect to database! Terminating application!");
			e.printStackTrace();
		}
		MindtreeMain mm = new MindtreeMain();
		int i = 1;
		while (i == 1) {
			System.out.println("1. to enter the detail\n" + "2. fetch the detail\n" + "3. to exit");
			int key = in.nextInt();
			switch (key) {
			case 1:
				Mindtree m = mm.createminds();
				
				try {
					ms.insertmind(m);
				} catch (ServiceException e) {
					
					e.printStackTrace();
				}
				
				break;
			case 2:
				List<Mindtree> ml = ms.getAllminds();
				mm.display(ml);

				break;
			case 3:
				i = 0;
				break;

			default:
				break;
			}
		}

	}

	private Mindtree createminds() {
		// TODO Auto-generated method stub
		System.out.println("enter the id of mind");
		int id = in.nextInt();
		in.nextLine();
		System.out.println("enter the name of mind");
		String name = in.nextLine();
		System.out.println("ente the address of minds");
		String address = in.nextLine();
		Mindtree m = new Mindtree(id, name, address);
		return m;

	}

	private void display(List<Mindtree> mind) {
		for (Mindtree i : mind) {
			System.out.println(i.getMid());
			System.out.println(i.getName());
			System.out.println(i.getAddress());

		}
	}

}
