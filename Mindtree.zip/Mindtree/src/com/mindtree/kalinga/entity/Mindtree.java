package com.mindtree.kalinga.entity;

public class Mindtree {
	int Mid;
	String name;
	String address;
	public Mindtree(int mid, String name, String address) {
		
		Mid = mid;
		this.name = name;
		this.address = address;
	}
	public int getMid() {
		return Mid;
	}
	public void setMid(int mid) {
		Mid = mid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	

}
