package com.mindtree.kalinga.dao;

import java.util.List;

import com.mindtree.kalinga.entity.Mindtree;

public interface Mindtreedao {
	public void insertMindToDb(Mindtree m);
	public List<Mindtree> getAllMindFromDb();

}
