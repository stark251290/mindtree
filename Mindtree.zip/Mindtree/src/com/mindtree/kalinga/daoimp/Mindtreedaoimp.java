package com.mindtree.kalinga.daoimp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.mindtree.kalinga.dao.Mindtreedao;
import com.mindtree.kalinga.entity.Mindtree;
import com.mindtree.kalinga.utility.JdbcConnection;
import com.mysql.jdbc.Statement;
public class Mindtreedaoimp implements Mindtreedao {

	@Override
	public void insertMindToDb(Mindtree m) {
		Connection con = JdbcConnection.getConnection();
		String query = "insert into mindtree values(?,?,?);";
		PreparedStatement ps = null;

		try {
			ps = con.prepareStatement(query);
			ps.setInt(1, m.getMid());
			ps.setString(2, m.getName());
			ps.setString(3, m.getAddress());
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}

	}

	@Override
	public List<Mindtree> getAllMindFromDb() {
		// TODO Auto-generated method stub
		List<Mindtree> mtl = new ArrayList<Mindtree>();
		Connection con = JdbcConnection.getConnection();
		String query = "select * from mindtree;";
		Statement st = null;
		ResultSet rs = null;
		try {
			st = (Statement) con.createStatement();
			rs = st.executeQuery(query);
			while (rs.next()) {
				Mindtree m = new Mindtree(rs.getInt(1), rs.getString(2), rs.getString(3));
				mtl.add(m);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();	
		}

		return mtl;
	}

}

