package com.mindtree.kalinga.serviceimp;

import java.util.List;

import com.mindtree.kalinga.dao.Mindtreedao;
import com.mindtree.kalinga.daoimp.Mindtreedaoimp;
import com.mindtree.kalinga.entity.Mindtree;
import com.mindtree.kalinga.exception.ServiceException;
import com.mindtree.kalinga.service.Mindtreeservice;

public class Mindtreeserviceimp implements Mindtreeservice {

	Mindtreedao md = new Mindtreedaoimp();

	@Override
	public void insertmind(Mindtree m) throws ServiceException {
		
		try {
			md.insertMindToDb(m);
			
		} catch (Exception e) {
			
			throw new ServiceException("service Exception occures",e);
		}
		
	

	}

	@Override
	public List<Mindtree> getAllminds() {
		// TODO Auto-generated method stub

		return md.getAllMindFromDb();
	}

}
